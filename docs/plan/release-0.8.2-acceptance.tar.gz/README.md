# Actual 0.8.2 acceptance evidence

Published source: 3dcc0aa9d7f0c2a585fe26fdf1ea6cc9bfd99b43 (v0.8.2).
Builder: Rust 1.96.1 on ARM64 macOS. Consumer dependencies resolve the public
registry package, with only the README lite feature (metrics/tracing included),
not a repository path dependency or gateway feature. Its independent workspace
has the exact resolved lockfile. Cached registry dependencies were used offline.

To run the consumer against its task-only local HTTP mock, use Python 3.10+
with requests/PyYAML, then in a separate terminal run cargo run --locked
--manifest-path consumer/Cargo.toml. The fake credential is intentionally local;
no vendor call or production database is used.

python3 - <<'PYMOCK'
import runpy, http.server, socketserver
module = runpy.run_path('release_smoke.py')
server = http.server.ThreadingHTTPServer(('127.0.0.1', 18463), module['Mock'], bind_and_activate=False)
socketserver.TCPServer.server_bind(server)
server.server_name = 'consumer-mock'
server.server_port = 18463
server.server_activate()
server.serve_forever()
PYMOCK

The locked consumer compiled and received three successful mock replies through
DefaultRouter::from_runtime, LLMClient::from_runtime and completion using the
installed default runtime. See consumer/result.json and build-run.log.

All four final artifact reports include compact and Gemini SSE: actual optimized
registry-installed executable and macOS ARM64 archive each passed 10 checks;
actual published GHCR ARM64 and amd64 each passed 13. Original five-platform
publisher smoke logs contain 8 checks each and remain separate. Both token-count
paths are selected upstream admission calls, not declared public gateway routes.

Reproduce executable/container TLS fixture setup with the commands in
../gateway/release-0.8.0-verification.md. The immutable publisher, public crate,
archive and Homebrew metadata are under publication/. Manifest digests identify
published content rather than local Docker image config IDs. No certificates or
private keys are in this archive. Earlier unsuccessful runs are excluded from
these final reports; their status is preserved in the main verification record.
