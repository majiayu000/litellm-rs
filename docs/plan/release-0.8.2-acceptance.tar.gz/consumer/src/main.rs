use std::sync::Arc;
use litellm_rs::{completion, user_message, CompletionOptions, Router, VERSION};
use litellm_rs::core::{
    completion::DefaultRouter,
    net::ProviderEndpointAccess,
    providers::{base::BaseConfig, openai::{OpenAIConfig, OpenAIProvider}, Provider},
    router::{install_default_runtime, Deployment, RuntimeBinding, UnifiedRouter},
};
use litellm_rs::sdk::{LLMClient, types::{Content, Message, Role}};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    assert_eq!(VERSION, "0.8.2");
    let provider = OpenAIProvider::new(OpenAIConfig {
        base: BaseConfig {
            api_key: Some("sk-ReleaseConsumerOnlyNoVendorCalls1234567890".into()),
            api_base: Some("http://127.0.0.1:18463/v1".into()),
            endpoint_access: ProviderEndpointAccess::PrivateNetwork,
            ..Default::default()
        },
        ..Default::default()
    }).await?;
    let router = Arc::new(UnifiedRouter::default());
    router.add_deployment(Deployment::new(
        "release-consumer".into(), Provider::OpenAI(provider),
        "gpt-4o-mini".into(), "consumer-model".into(),
    ));
    let binding = RuntimeBinding::new(router);
    install_default_runtime(binding.clone())?;
    let response = DefaultRouter::from_runtime(binding.clone()).complete(
        "consumer-model", vec![user_message("hello")], CompletionOptions::default(),
    ).await?;
    assert_eq!(response.model, "gpt-4o-mini");
    let sdk = LLMClient::from_runtime(binding, "consumer-model")?;
    let response = sdk.chat(vec![Message {
        role: Role::User, content: Some(Content::Text("hello".into())),
        name: None, tool_calls: None,
    }]).await?;
    assert_eq!(response.model, "gpt-4o-mini");
    let response = completion("consumer-model", vec![user_message("hello")], None).await?;
    assert_eq!(response.model, "gpt-4o-mini");
    println!("published crate {}: DefaultRouter, LLMClient and completion passed", VERSION);
    Ok(())
}
